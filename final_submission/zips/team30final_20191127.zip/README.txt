***DESCRIPTION***
This package contains a web application to visualize opioid-related mortality data. It contains:
- HTML pages
- Data used in visualizations


***INSTALLATION***
You must be able to launch a simple web server on your machine in order to execute this code, as the code reads a file from the extracted .ZIP. We recommend using Python's http module, which is part of the standard library.

Other than that, no special installation is required. All required data and code is included in the .ZIP archive. Unzip the archive into a directory of your choice.


***EXECUTION***
1. Launch a command line prompt/terminal window
2. In the command line/terminal, navigate to the directory containing the unzipped files (e.g. `cd C:\jakewama`)
3. Launch a web server (e.g. `python -m http.server 8888`)
4. Launch a web browser of your choice (we recommend Chrome or Firefox)
5. Connect to your local web server (e.g. `localhost:8888`)